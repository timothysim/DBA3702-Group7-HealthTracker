## Library---------------------------------------------------------------------------------------------------------------------------
library(shinyWidgets)
library(shinydashboard)
library(shiny)
library(shinythemes)
library(plotly)
library(leaflet)
library(DT)
library(dplyr)


## Files---------------------------------------------------------------------------------------------------------------------------
# Set your working directory here
# setwd("/Users/Ivan/Documents/Y2S2/DBA3702/DBA3702 Assignments/DBA Project")

food_data <- read.csv("Project-Food-Data.csv")

exercise_data <-read.csv('exercise_dataset.csv')

exercise_data <- subset(exercise_data, select = -Calories.per.kg)
names <- c('Exercises', 'Lightweight', 'Middleweight','Light_Heavyweight','Heavweight')
names(exercise_data) <- names

#divide by 60 to get the calories burnt per minute
exercise_data$Lightweight <- round(exercise_data$Lightweight/60,2)
exercise_data$Middleweight <- round(exercise_data$Middleweight/60,2)
exercise_data$Light_Heavyweight <- round(exercise_data$Light_Heavyweight/60,2)
exercise_data$Heavweight <- round(exercise_data$Heavweight/60,2)


#create 4 data sets
lightweight_data <- subset(exercise_data, select = c('Exercises','Lightweight'))
middleweight_data <- subset(exercise_data, select = c('Exercises','Middleweight'))
light_heavyweight_data <- subset(exercise_data, select = c('Exercises','Light_Heavyweight'))
heavyweight_data <- subset(exercise_data, select = c('Exercises','Heavweight'))

#rename the columns in 4 dataframes
names_2 <- c('Exercises', 'Calories')
names(lightweight_data) <- names_2
names(middleweight_data) <- names_2
names(light_heavyweight_data) <- names_2
names(heavyweight_data) <- names_2

lst <- list(lightweight_data,middleweight_data,light_heavyweight_data,heavyweight_data)

## UI---------------------------------------------------------------------------------------------------------------------------
ui <- bootstrapPage(
  navbarPage(theme = shinytheme("cosmo"),
             HTML('<a style="text-decoration:none;cursor:default;color:#FFFFFF;" class="active" href="#">All-in-1 Tracker</a>'), id="nav",
             windowTitle = "All-in-1 Tracker",
             tags$style(".navbar { background-color: #703f37; }"),
             tags$style("body { background-color: #316879; }"),
             
             
             ## First Tab---------------------------------------------------------------------------------------------------------------------------
             tabPanel("You",
                      icon = icon("user"), dashboardPage(
                        dashboardHeader(),
                        dashboardSidebar(
                          sidebarMenu(
                            menuItem("About You", tabName = "userDashboard", icon = icon("user"),
                                     dateInput(inputId = "you_date", "Date:", value = Sys.Date()),
                                     textInput("userName", "Name : ", value = "Your Name"),
                                     numericInput("userWeight", "Weight (in kg) : ", value = 60, min = 1, max = 1000, step = 1),
                                     numericInput("userHeight", "Height (in cm) : ", value = 160, min = 1, max = 300, step = 1),
                                     sliderInput("userAge", "Age : ", 0, 100, 20),
                                     radioButtons("userGender", "Gender", choices = list("Male" = "male", "Female" = "female"), selected = "male"),
                                     pickerInput("userGoal", "Current Goal:",   
                                                 choices = c("Weight loss", "Weight gain", "Maintain weight", "Improve sleep", "Improve diet"), 
                                                 options = list(`actions-box` = TRUE, `none-selected-text` = "Please make a selection!"),
                                                 selected = c("Improve overall health"),
                                                 multiple = FALSE),
                                     actionButton("update", "Update Info")
                            ))),
                        dashboardBody(
                          fluidRow(
                            infoBoxOutput("usersName"),
                            infoBoxOutput("usersWeight"),
                            infoBoxOutput("usersHeight")
                          ),
                          fluidRow(
                            infoBoxOutput("usersAge"),
                            infoBoxOutput("usersGender"),
                            infoBoxOutput("usersBMI")
                          ),
                          fluidRow(
                            infoBoxOutput("usersGoal"),
                          ),
                          fluidRow(
                            infoBoxOutput("")  
                          ),
                          fluidRow(
                            tableOutput("weighttrack")
                          )
                        )
                      )),
             
             ## Second Tab---------------------------------------------------------------------------------------------------------------------------
             tabPanel("Food",
                      icon = icon("utensils"),
                      dashboardPage(
                        dashboardHeader(),
                        
                        #Side Bar
                        dashboardSidebar(
                          sidebarMenu(
                            menuItem("Food Taken", tabName = "widgets", icon = icon("utensils"),
                                     dateInput(inputId = "nutri_date", "Date:", value = Sys.Date()),
                                     selectizeInput(
                                       'food_name', 'Food_name', choices = unique(food_data$Name),
                                       options = list(
                                         placeholder = 'Type to search for food',
                                         onInitialize = I('function() { this.setValue(""); }')
                                       ),
                                     ),
                                     
                                     conditionalPanel('input.food_name != ""', 
                                                      selectizeInput('restaurant','Restaurtant',choices = c("Type to search for restaurant")),
                                                      selectizeInput('portion', 'Portion', choices = c("Portion")),
                                                      numericInput('quantity', 'Quantity', value = 1, min = 0, step = 1)),
                                     actionButton("add", "Add ingredient"),
                                     actionButton("remove", "Remove ingredient")
                            ))),
                        
                        #Main Part
                        dashboardBody(
                          # Row 1
                          fluidRow(
                            tabBox(
                              title = tagList(shiny::icon("hamburger")),
                              width = 4,
                              tabPanel(title = "Food List Table",
                                       div(DT::DTOutput("food_df"), style = "font-size: 80%;"))),
                            box(
                              title = tagList(shiny::icon("chart-simple")),
                              width = 8,
                              valueBoxOutput("calories", width = 6),
                              valueBoxOutput("carbohydrate", width = 6),
                              valueBoxOutput("fats", width = 6),
                              valueBoxOutput("protein", width = 6))
                          ),
                          
                          # Row 2
                          fluidRow(
                            tabBox(
                              title = tagList(shiny::icon("fire")),
                              width = 4,
                              tabPanel("Calories", 
                                       plotlyOutput("calo_plot"))),
                            tabBox(
                              title = tagList(shiny::icon("bowl-food")),
                              width = 8,
                              tabPanel("Macronutrients", 
                                       plotlyOutput("macro_plot")))
                          )
                        ))),
             
             ## Third Tab---------------------------------------------------------------------------------------------------------------------------
             
             tabPanel("Workout",
                      icon = icon("dumbbell"),
                      dashboardPage(
                        dashboardHeader(),
                        dashboardSidebar(
                          sidebarMenu(
                            menuItem("Activity Done", tabName = "activity", icon = icon("dumbbell"),
                                     dateInput(inputId = "WorkoutDate", label = "Date:", value = Sys.Date()),
                                     selectizeInput(inputId = "exercise_select", label = "Select exercise",
                                                    choices = exercise_data$Exercises, multiple = TRUE),
                                     numericInput("activityDuration", "Time of Activity (Minutes) : ", 0, 240, 30),
                                     actionButton("workout_submit", "Submit"),
                                     actionButton("reset_activities", "Reset Workouts")
                            ))),
                        
                        dashboardBody(
                          
                          #Row 1
                          fluidRow(
                            tabBox(
                              title = tagList(shiny::icon("table")),
                              tabPanel(title = "Your Activities",
                                       div(DT::DTOutput("exercise_table"), style = "font-size: 80%;"))),
                            
                            #row 2
                            tabBox(
                              title = tagList(shiny::icon("fire")),
                              tabPanel(title = "Calories Burned",
                                       strong(h2("Your Activity Today")),
                                       strong(h4(textOutput(outputId = "calBurnedText")),
                                       )))
                            
                          ),
                          
                          #Row 3
                          fluidRow(
                            tabBox(
                              title = tagList(shiny::icon("running")),
                              tabPanel(title = "Calories Burned Graph",
                                       plotOutput(outputId = "plot_caloriesBurned"))
                            ))))),
             
             ## Fourth Tab---------------------------------------------------------------------------------------------------------------------------
             
             tabPanel("Sleeping",
                      icon = icon("bed"),
                      dashboardPage(
                        dashboardHeader(),
                        dashboardSidebar(
                          sidebarMenu(
                            menuItem("Sleep", tabName = "Sleep", icon = icon("bed")),
                            dateInput(inputId = "date", "Date:", value = Sys.Date()),
                            sliderInput("slider1", label = h3("Rate Your Sleeping Quality"), min = 0, 
                                        max = 10, value = 5),
                            selectInput("bedtime", label = h3("Bedtime"), 
                                        choices = list("1am" = 1, "2am" = 2, "3am" = 3,"4am"=4,"5am"=5,"6am"=6,"7am"=7,"8am"=8,"9am"=9,"10am"=10,"11am"=11,"12pm"=12,"1pm"=13,"2pm"=14,"3pm"=15,"4pm"=16,"5pm"=17,"6pm"=18,"7pm"=19,"8pm"=20,"9pm"=21,"10pm"=22,"11pm"=23,"12am"=0), 
                                        selected = 1),
                            selectInput("wakeup", label = h3("Wake Up"), 
                                        choices = list("1am" = 1, "2am" = 2, "3am" = 3,"4am"=4,"5am"=5,"6am"=6,"7am"=7,"8am"=8,"9am"=9,"10am"=10,"11am"=11,"12pm"=12,"1pm"=13,"2pm"=14,"3pm"=15,"4pm"=16,"5pm"=17,"6pm"=18,"7pm"=19,"8pm"=20,"9pm"=21,"10pm"=22,"11pm"=23,"12am"=0), 
                                        selected = 1),
                            actionButton("addBtn", "Add Sleep")
                          )
                        ),
                        dashboardBody(
                          tabItems(
                            tabItem(
                              tabName = "Sleep",
                              h4("Sleep Tracker"),
                              tableOutput("table"),
                              br(),
                              h4("Average Sleep"),
                              textOutput("average"),
                              br(),
                              h4("Sleep Status"),
                              textOutput("status")
                            )
                          )
                        )
                      )
             ),
             
             
             # Move the closing bracket for tabPanel here
             
             
             ## Fifth Tab---------------------------------------------------------------------------------------------------------------------------
             tabPanel("History",
                      icon = icon("history"),
                      dashboardPage(
                        dashboardHeader(),
                        dashboardSidebar(
                          sidebarMenu(
                            menuItem("History", tabName = "history", icon = icon("history"),
                                     dateRangeInput(inputId = "date_range", label = "Select date range:",
                                                    start = Sys.Date() - 30, end = Sys.Date(),
                                                    min = "2020-01-01", max = Sys.Date(),
                                                    separator = " - ", format = "yyyy-mm-dd")#,
                                     #submitButton(text = "Submit")
                            ))),
                        dashboardBody(
                          fluidRow(
                            tabBox(
                              title = tagList(shiny::icon("history")),
                              width = 6,
                              tabPanel("Sleep Log", 
                                       plotlyOutput("sleep"))),
                            tabBox(
                              title = tagList(shiny::icon("bowl-food")),
                              width = 6,
                              tabPanel("Calorie Intake", 
                                       plotlyOutput("cal_plot"))),
                            tabBox(
                              title = tagList(shiny::icon("running")),
                              width = 6,
                              tabPanel("Calories Burned", 
                                       plotlyOutput("burn"))),
                            tabBox(
                              title = tagList(shiny::icon("fire")),
                              width = 6,
                              tabPanel("Overall Progress", 
                                       plotlyOutput("overall")))
                          )
                        )))
             
  ))




## Server---------------------------------------------------------------------------------------------------------------------------
server = function(input, output, session) {
  
  ## First Tab---------------------------------------------------------------------------------------------------------------------------
  
  output$usersName <- renderInfoBox({
    infoBox(
      "User's Name", input$userName, icon = icon("user"), color = "blue", fill = TRUE
    )
  })
  
  output$usersWeight <- renderInfoBox({
    infoBox(
      "User's Weight", paste(input$userWeight, "KG"), icon = icon("weight"), color = "purple", fill = TRUE
    )
  })
  output$usersHeight <- renderInfoBox({
    infoBox(
      "User's Height", paste(input$userHeight, "CM"), icon = icon("ruler-vertical"), color = "yellow", fill = TRUE
    )
  })
  output$usersAge <- renderInfoBox({
    infoBox(
      "User's Age", paste(input$userAge, "Years"), icon = icon("sort-numeric-down"), color = "fuchsia", fill = TRUE
    )
  })
  output$usersGender <- renderInfoBox({
    gender <- switch(input$userGender,
                     male = "Male",
                     female = "Female")
    infoBox(
      "User's Gender", gender, icon = icon("venus-mars"), color = "teal", fill = TRUE
    )
  })
  output$usersBMI <- renderInfoBox({
    BMI <- input$userWeight/((input$userHeight)/100)^2
    if(BMI < 18.5){
      colourChoosen <- "blue"
        status <- "Underweight"
    }else if(BMI>=18.5 && BMI<=24.9){
      colourChoosen <- "green"
        status <- "Healthy"
    }else if(BMI>=25.0 && BMI<=29.9){
      colourChoosen <- "orange"
        status <- "Overweight"
    }else{
      colourChoosen <- "red"
        status <- "Obesity"
    }
    
    infoBox(
      "User's BMI", sprintf(BMI, fmt = '%#.2f'), status, icon = icon("balance-scale"), color = colourChoosen, fill=TRUE
    )
  })
  
  output$usersGoal <- renderInfoBox({
    infoBox(
      "User's Goal", paste(input$userGoal), icon = icon("fire"), color = "navy", fill = TRUE
    )
  })
  ### SEction 5
  weight_data <- reactiveValues(data = data.frame("Date" = as.Date(character()), 
                                                  "Weight" = numeric(), 
                                                  stringsAsFactors = F))
  
  ###
  
  # Initialize a reactiveValues object to store the table data
  table_data <- reactiveValues(data = data.frame(Date = character(), Name = character(),
                                                 Weight = numeric(), Height = numeric(),
                                                 Age = numeric(), Gender = character(),
                                                 Goal = character(), BMI = numeric()))
  
  # Define a reactive function that updates the user's information and adds it to the table data
  user_info <- reactive({
    data.frame(Date = input$you_date, Name = input$userName, Weight = input$userWeight,
               Height = input$userHeight, Age = input$userAge, Gender = input$userGender,
               Goal = input$userGoal, BMI = input$userWeight / ((input$userHeight) / 100) ^ 2)
  })
  
  # Update the table data with the new user info every time the "Update Info" button is clicked
  observeEvent(input$update, {
    new_row <- user_info()
    new_row$Date <- as.character(new_row$Date)
    table_data$datax <- rbind(table_data$datax, new_row)
    #### Section 5
    new_weight_row <- new_row[, c("Date", "Weight")]
    weight_data$data <- rbind(weight_data$data, new_weight_row)
    ####
  })
  #### Section 5
  weight <- reactive({
    weight_data$data %>% group_by(Date) %>% summarise(Weight = sum(Weight))
  })
  #####
  
  
  # Render the table in the UI
  output$weighttrack <- renderTable({
    table_data$datax
  })
  
  
  ## Second Tab---------------------------------------------------------------------------------------------------------------------------
  ####FOR SECTION 5 GRAPH make reactive to store calorie data for graph
  cal_df <- shiny::reactiveValues()
  cal_df$df <- data.frame("Date" = as.Date(character()), 
                          "Calories" = numeric(), 
                          stringsAsFactors = F)
  ####
  
  # make reactive to store ingredients
  food_df <- shiny::reactiveValues()
  
  food_df$df <- data.frame("Food" = character(), 
                           "Quantity" = numeric(), 
                           "Units" = character(),
                           "Date" = as.Date(character(), "%Y-%m-%d"),
                           stringsAsFactors = F)
  food_df$nutri <- data.frame("Food" = character(),
                              "Calories" = numeric(),
                              "Carbohydrate" = numeric(),
                              "Fat" = numeric(),
                              "Protein" = numeric(),
                              "Date" = as.Date(character(), "%Y-%m-%d"),
                              stringsAsFactors = F)
  
  # step 1 get singular food
  match_df <- eventReactive(input$food_name,
                            {match_df <- food_data[food_data$Name==input$food_name,]
                            match_df
                            })
  
  # step 2 update the portion and restaurant unit for singular ingredient
  observe({
    units <- unique(match_df()$Portion)
    updateSelectInput(session, "portion", "Portion", choices = units)
  })
  
  observe({
    rest <- unique(match_df()$Restaurant)
    updateSelectInput(session, "restaurant", "Restaurant", choices = rest)
  })
  
  # step 3 update the food and nutrition dataframe
  observeEvent(input$remove, {
    isolate(food_df$df<-food_df$df[-(nrow(food_df$df)),])
    isolate(food_df$nutri<-food_df$nutri[-(nrow(food_df$nutri)),])
  })
  observeEvent(input$add, {
    isolate(food_df$df[nrow(food_df$df) + 1,] <- c(input$food_name,
                                                   input$quantity,
                                                   input$portion,
                                                   format(input$nutri_date, "%Y-%m-%d")))
    
    nutri_input <- match_df()[match_df()$Portion == input$portion && 
                                match_df()$Restaurant == input$restaurant, ]
    isolate(food_df$nutri[nrow(food_df$nutri) + 1,] <- c(input$food_name,
                                                         nutri_input$Calories * input$quantity,
                                                         nutri_input$Carbohydrate * input$quantity,
                                                         nutri_input$Fat * input$quantity,
                                                         nutri_input$Protein * input$quantity,
                                                         format(input$nutri_date, "%Y-%m-%d")))
    
    ####for section 5    
    isolate({
      date <- input$nutri_date
      calories <- sum(as.numeric(food_df$nutri$Calories))
      cal_df$df <- rbind(cal_df$df, data.frame("Date" = date, "Calories" = calories))
    })
  })
  cal_df_summarized <- reactive({
    cal_df$df %>% group_by(Date) %>% summarise(Calories = sum(Calories))
  })
  #####
  
  
  
  # #Output 1: Table
  # output$food_df <- DT::renderDataTable(food_df$df[food_df$df$Date == input$nutri_date,1:3], 
  #                                       rownames=F, options = list(pageLength = 5))
  #Output 1: Table
  output$food_df <- DT::renderDataTable({
    subset(food_df$df[,1:3], food_df$df[,4] == format(input$nutri_date, "%Y-%m-%d"))
  }, rownames=F, options = list(pageLength = 5))
  #Output 2: Macro nutrients barplot
  output$macro_plot <- renderPlotly({

    cols_to_plot <- c("Food", "Carbohydrate", "Fat", "Protein")
    data_to_plot <- food_df$nutri[food_df$nutri$Date == format(input$nutri_date, "%Y-%m-%d"), cols_to_plot]
    data_to_plot_long <- tidyr::gather(data_to_plot, Nutrients, Value, 2:4)
    
    # create the stacked bar graph
    ggplot(data_to_plot_long, aes(x = Nutrients, y = as.numeric(Value), fill = Food)) +
      geom_bar(position = "stack", stat = "identity") +
      xlab("Nutrients") +
      ylab("grams (g)") + 
      theme(axis.text.x = element_text()) + 
      scale_x_discrete(limits = c("Carbohydrate", "Fat", "Protein")) +
      ggtitle("Nutrient breakdown")
  })
  
  #Output 3: Calories bar graph
  output$calo_plot <- renderPlotly({
    cols_to_plot <- c("Food", "Calories")
    data_to_plot <- food_df$nutri[food_df$nutri$Date == format(input$nutri_date, "%Y-%m-%d"), cols_to_plot]
    data_to_plot_long <- tidyr::gather(data_to_plot, Nutrients, Value, 2)
    
    # create the stacked bar graph
    ggplot(data_to_plot_long, aes(x = Nutrients, y = as.numeric(Value), fill = Food)) +
      geom_bar(position = "stack", stat = "identity") +
      ylab("kcal") + 
      theme(axis.text.x = element_text()) + 
      scale_x_discrete(limits = c("Calories")) +
      ggtitle("Calories breakdown")
  })
  
  #Output 4 - 7: Value Boxes
  output$calories <- renderValueBox({
    a <- food_df$nutri %>% filter(Date == format(input$nutri_date, "%Y-%m-%d")) %>% summarise(Calories = sum(as.numeric(Calories))) %>% pull(Calories)
    valueBox(paste0(a, "kcal"), 
             "Calories", icon = icon("fire"), color = "red")
  })
  
  output$carbohydrate <- renderValueBox({
    a <- food_df$nutri %>% filter(Date == format(input$nutri_date, "%Y-%m-%d")) %>% summarise(Carbohydrate = sum(as.numeric(Carbohydrate))) %>% pull(Carbohydrate)
    valueBox(paste0(a, "g"), 
             "Carbohydrate", 
             icon = icon("cubes-stacked"), 
             color = "green")
  })
  
  output$fats <- renderValueBox({
    a <- food_df$nutri %>% filter(Date == format(input$nutri_date, "%Y-%m-%d")) %>% summarise(Fat = sum(as.numeric(Fat))) %>% pull(Fat)
    valueBox(paste0(a, "g"), 
             "Fat", icon = icon("bottle-droplet"), color = "yellow")
  })
  
  output$protein <- renderValueBox({
    a <- food_df$nutri %>% filter(Date == format(input$nutri_date, "%Y-%m-%d")) %>% summarise(Protein = sum(as.numeric(Protein))) %>% pull(Protein)
    valueBox(paste0(a, "g"), 
             "Protein", icon = icon("egg"), color = "orange")
  })
  
  ## Third Tab--------------------------------------------------------------------------------------------------------------------------
  ####for section 5
  exercise <- shiny::reactiveValues(data = data.frame("Date" = as.Date(character()),
                                                      "Calburn" = numeric(),
                                                      stringsAsFactors = F))
  ########
  
  #choose which dataframe to use
  selected_data <- reactive({
    if (input$userWeight <= 64) {
      return(lst[[1]]) 
    } else if (input$userWeight > 64 & input$userWeight <= 76) {
      return(lst[[2]]) 
    } else if (input$userWeight > 76 & input$userWeight <= 88) {
      return(lst[[3]]) 
    } else {
      return(lst[[4]]) 
    }
  })
  
  exercise_data <- reactiveValues(
    date = character(),
    exercises = character(),
    durations = numeric(),
    calories = numeric()
  )
  
  observeEvent(input$workout_submit, {
    # Get the selected exercises from the selectizeInput
    selected_exercises <- input$exercise_select
    
    selected_exercises_list <- split(selected_exercises, seq_along(selected_exercises))
    # Get the workout date from the dateInput
    workout_date <- input$WorkoutDate
    # Get the duration of the workout from the numericInput
    workout_duration <- input$activityDuration
    # Get the selected data based on the user's weight
    selected_df <- selected_data()
    # Filter the selected data based on the selected exercises
    filtered_df <- selected_df[selected_df$Exercise %in% selected_exercises, ]
    # Calculate the calories burned based on the duration and calorie information
    calories_burned <- filtered_df$Calories * workout_duration
    # Update the exercise_data reactive value with the new data
    exercise_data$exercises <- c(exercise_data$exercises, sapply(selected_exercises_list, paste, collapse = "\n"))
    exercise_data$durations <- c(exercise_data$durations, workout_duration)
    exercise_data$calories <- c(exercise_data$calories, round(calories_burned, 2))

#### SECTION 5
    isolate({
      date <- input$WorkoutDate
      calories <- filtered_df$Calories * workout_duration
      exercise$data <- rbind(exercise$data, data.frame("Date" = date, "Calburn" = calories))
    })
#####
    
    # Clear the selectizeInput
    updateSelectizeInput(session, "exercise_select", selected = character(0))
  })
  
  #### SEC5
  exercisesum <- reactive({
    exercise$data %>% group_by(Date) %>% summarise(Calburn = sum(Calburn))
  })
  ####
  
  output$exercise_table <- DT::renderDT({
    DT::datatable(
      data.frame(
        Exercise = exercise_data$exercises,
        Duration = exercise_data$durations,
        Calories = exercise_data$calories
      ),
      options = list(
        pageLength = 10,
        dom = 'tp',
        ordering = FALSE
      ),
      rownames = FALSE,
      class = "compact hover"
    )
  })
  
  output$calBurnedText <- renderText({
    total_minutes <- sum(exercise_data$durations)
    total_calories <- sum(exercise_data$calories)
    
    paste("You have exercised for", total_minutes, "minutes today and have burnt a total of", total_calories, "calories.")
  })
  
  
  output$plot_caloriesBurned <- renderPlot({
    if (length(exercise_data$calories) == 0) {
      return(NULL) # don't render anything if exercise_data is empty
    }
    
    # create a data frame with the top 5 exercises by calories burned
    top_exercises <- data.frame(
      Exercise = exercise_data$exercises,
      Calories = exercise_data$calories
    )
    top_exercises <- top_exercises[order(-top_exercises$Calories),][1:5,]
    top_exercises <- na.omit(top_exercises)
    
    # create a ggplot bar chart with the top 5 exercises
    ggplot(top_exercises, aes(x = Exercise, y = Calories, fill=Exercise)) +
      geom_bar(stat = "identity") +
      ggtitle("Top Exercises by Calories Burned") +
      xlab("Exercise") +
      ylab("Calories Burned") +
      theme(axis.text.x = element_text(angle = 45, hjust = 1), legend.position = "none")
  })
  
  observeEvent(input$reset_activities, {
    exercise_data$exercises <- character()
    exercise_data$durations <- numeric()
    exercise_data$calories <- numeric()
  })
  
  
  ## Fourth Tab--------------------------------------------------------------------------------------------------------------------------
  ## age group function for sleep tab
  age_group <- function(age) {
    if(age < 1) {
      return("Infant")
    } else if(age >= 1 & age <= 2) {
      return("Toddler")
    } else if(age >= 3 & age <= 5) {
      return("Preschool")
    } else if(age >= 6 & age <= 12) {
      return("School Age")
    } else if(age >= 13 & age <= 18) {
      return("Teen")
    } else if(age >= 18 & age <= 60) {
      return("Adult")
    } else if(age >= 61 & age <= 64) {
      return("Middle-aged")
    } else if(age >= 65) {
      return("Senior")
    } else {
      return("Invalid age")
    }
  }
  calculate_sleep_status <- function(usersAge, SleepHour) {
    age_group_name <- age_group(input$userAge)
    recommended_sleep_hours <- switch(age_group_name,
                                      "Newborn" = c(14, 17),
                                      "Infant" = c(12, 16),
                                      "Toddler" = c(11, 14),
                                      "Preschool" = c(10, 13),
                                      "School Age" = c(9, 12),
                                      "Teen" = c(8, 10),
                                      "Adult" = c(7, Inf),
                                      "61-64 years" = c(7, 9),
                                      "65 years and older" = c(7, 8))
    total_sleep_hours <- as.numeric(SleepHour)
    if (total_sleep_hours < recommended_sleep_hours[1]) {
      status <- "Insufficient sleep"
    } else if (total_sleep_hours > recommended_sleep_hours[2]) {
      status <- "Too much sleep"
    }else{
      status <- "Sufficient sleep"
    }
    status
  }
  
  # Create reactive data frame
  sleep_data <- reactiveValues(data = data.frame(Date = character(),
                                                 Bedtime = character(),
                                                 WakeUp = character(),
                                                 Quality = numeric(),
                                                 SleepHour = numeric(),	
                                                 Status = character()))
  # Add sleep data
  observeEvent(input$addBtn, {
    # Check if WakeUp is after Bedtime and only one entry per date
    if (as.numeric(input$wakeup) > as.numeric(input$bedtime)) {
      sleep_hours <- as.numeric(input$wakeup) - as.numeric(input$bedtime)
      new_row <- data.frame(Date = format(input$date, "%Y-%m-%d"),
                            Bedtime = input$bedtime,
                            WakeUp = input$wakeup,
                            Quality = input$slider1,
                            SleepHour = sleep_hours,
                            Status = calculate_sleep_status(as.numeric(input$userAge), sleep_hours))
      # Check if there is already an entry for the same date
      if (!format(input$date, "%Y-%m-%d") %in% sleep_data$data$Date) {
        sleep_data$data <- rbind(sleep_data$data, new_row)
      } else {
        # Replace the existing entry for the same date
        sleep_data$data[sleep_data$data$Date == format(input$date, "%Y-%m-%d"), ] <- new_row
      }
    } else if (as.numeric(input$wakeup) < 12 && as.numeric(input$bedtime) >= 12) {
      # Adjust WakeUp time if it's before 10am and Bedtime is after 10pm
      sleep_hours <- (as.numeric(input$wakeup) + 24) - as.numeric(input$bedtime)
      new_row <- data.frame(Date = format(input$date, "%Y-%m-%d"),
                            Bedtime = as.numeric(input$bedtime),
                            WakeUp = as.numeric(input$wakeup) + 24,
                            Quality = input$slider1,
                            SleepHour = sleep_hours,
                            Status = calculate_sleep_status(as.numeric(input$userAge), sleep_hours))
      # Check if there is already an entry for the same date
      if (!format(input$date - 1, "%Y-%m-%d") %in% sleep_data$data$Date) {
        sleep_data$data <- rbind(sleep_data$data, new_row)
      } else {
        # Replace the existing entry for the same date
        sleep_data$data[sleep_data$data$Date == format(input$date - 1, "%Y-%m-%d"), ] <- new_row
      }
    } else {
      # Show an error message if WakeUp is before Bedtime
      showModal(modalDialog(
        title = "Error",
        "WakeUp time must be after Bedtime!",
        easyClose = TRUE
      ))
    }
    # Sort the sleep data by date and update the table
    sleep_data$data <- sleep_data$data %>% arrange(Date)
  })
  
  
  
  # Render table of sleep data
  output$table <- renderTable({
    sleep_data$data
  })
  
  # Calculate average sleep time
  output$average <- renderText({
    avg_sleep <- ifelse(nrow(sleep_data$data)==0,0,mean(as.numeric(sleep_data$data$WakeUp) - as.numeric(sleep_data$data$Bedtime)))
    paste("Average Sleep Time: ", avg_sleep, " hours")
  })
  
  
  # Calculate sleep status
  output$status <- renderText({
    avg_sleep <- ifelse(nrow(sleep_data$data)==0,0,mean(as.numeric(sleep_data$data$WakeUp) - as.numeric(sleep_data$data$Bedtime)))
    paste("Average Sleeping Status: ", calculate_sleep_status(as.numeric(input$userAge), avg_sleep)) 
    
  })
  
  ###for section 5###
  # Create reactive data frame for sleep summary
  sleep_summary <- shiny::reactiveValues()
  sleep_summary <- reactive({
    sleep_data$data %>%
      group_by(Date) %>%
      summarise(SleepHours = sum(as.numeric(WakeUp) - as.numeric(Bedtime)))
  })
  ######
  
  
  
  ## Fifth Tab--------------------------------------------------------------------------------------------------------------------------
  #sleep
  sleep_subset <- reactive({
    sleep_summary() %>% filter(Date >= input$date_range[1] & Date <= input$date_range[2])
  })
  output$sleep <- renderPlotly({
    plot_ly(sleep_subset(), x = ~Date, y = ~SleepHours, type = "scatter", mode = "lines+markers") %>%
      layout(xaxis = list(title = "Date"), yaxis = list(title = "Sleep Log"))
  })
  
  #Calorie graph
  cal_subset <- reactive({
    cal_df_summarized() %>% filter(Date >= input$date_range[1] & Date <= input$date_range[2])
  })
  output$cal_plot <- renderPlotly({
    plot_ly(cal_subset(), x = ~Date, y = ~Calories, type = "scatter", mode = "lines+markers") %>%
      layout(xaxis = list(title = "Date"), yaxis = list(title = "Calories Log"))
  })

  
  #Exercise graph
  exercise_subset <- reactive({
    exercisesum() %>% filter(Date >= input$date_range[1] & Date <= input$date_range[2])
  })
  output$burn <- renderPlotly({
    plot_ly(exercise_subset(), x = ~Date, y = ~Calburn, type = "scatter", mode = "lines+markers") %>%
      layout(xaxis = list(title = "Date"), yaxis = list(title = "Calories Log"))
  })
  
  weight_subset <- reactive({
    weight() %>% filter(Date >= input$date_range[1] & Date <= input$date_range[2])
  })
  
  output$overall <- renderPlotly({
    # Get the individual datasets
    sleep_subset_data <- sleep_subset()
    cal_subset_data <- cal_subset()
    weight_subset_data <- weight_subset()
    exercise_subset_data <- exercise_subset()
    
    # Create the initial plot with Calories data
    plot <- plot_ly(cal_subset_data, x = ~Date, y = ~Calories, type = "scatter", mode = "markers+lines", line = list(color = "green"), name = "Calories", yaxis = "y")
    
    # Add Weight data to the plot
    plot <- plot %>% add_trace(data = weight_subset_data, x = ~Date, y = ~Weight, type = "scatter", mode = "markers+lines", line = list(color = "blue"), name = "User Weight", yaxis = "y2")
    
    # Add Exercise data to the plot (assuming it has a column named "Exercise")
    plot <- plot %>% add_trace(data = exercise_subset_data, x = ~Date, y = ~Calburn, type = "scatter", mode = "markers+lines", line = list(color = "red"), name = "Exercise", yaxis = "y")
    
    # Set the layout for the plot
    plot <- plot %>% layout(title = "Overall Progress",
                            yaxis = list(title = "Calories Gained / Burnt"),
                            yaxis2 = list(title = "Weight (kg)", overlaying = "y", side = "right"))
  })
  
  
}

## ---------------------------------------------------------------------------------------------------------------------------
## App

shinyApp(ui, server)
